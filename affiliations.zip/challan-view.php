<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <title>Fee Challan - The Lynx School</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Alex+Brush&family=Great+Vibes&family=Nunito+Sans:wght@400;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <style>
        * { box-sizing: border-box; }
        body {
            margin: 0;
            background: #eef2f7;
            color: #172033;
            font-family: "Nunito Sans", -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Arial, sans-serif;
        }
        .page {
            max-width: 1050px;
            margin: 24px auto;
            padding: 0 16px;
        }
        .toolbar {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 14px;
        }
        .btn {
            display: inline-flex;
            gap: 7px;
            align-items: center;
            padding: 10px 14px;
            border: 1px solid #1d4ed8;
            border-radius: 6px;
            text-decoration: none;
            color: #1d4ed8;
            background: #fff;
            font-weight: 700;
        }
        .btn.primary { background: #1d4ed8; color: #fff; }
        .sheet {
            background: #fff;
            border: 1px solid #d7deea;
            border-radius: 10px;
            overflow: hidden;
            box-shadow: 0 10px 35px #0f172a12;
        }
        .brand {
            padding: 22px 28px;
            text-align: center;
            border-bottom: 4px solid #172554;
        }
        .brand img { height: 68px; }
        .brand h1 {
            margin: 8px 0 2px;
            font-family: "Edwardian Script ITC", "Great Vibes", "Alex Brush", cursive;
            font-size: 34px;
            line-height: 1.05;
            font-weight: 500;
            letter-spacing: .2px;
            color: #172554;
        }
        .brand p { margin: 0; color: #64748b; }
        .title {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 14px 24px;
            background: #172554;
            color: #fff;
        }
        .title h2 { margin: 0; font-size: 18px; }
        .badge {
            padding: 5px 10px;
            border-radius: 20px;
            background: #dcfce7;
            color: #166534;
            font-size: 12px;
            font-weight: 800;
        }
        .badge.overdue {
            background: #fee2e2;
            color: #991b1b;
        }
        .body { padding: 22px; }
        .meta {
            display: grid;
            grid-template-columns: repeat(3, 1fr);
            gap: 12px;
            margin-bottom: 20px;
        }
        .meta div {
            padding: 10px 12px;
            background: #f8fafc;
            border: 1px solid #e2e8f0;
            border-radius: 6px;
        }
        .meta label {
            display: block;
            color: #64748b;
            font-size: 11px;
            font-weight: 700;
            text-transform: uppercase;
            margin-bottom: 4px;
        }
        .meta strong { font-size: 13px; }
        .section-title {
            font-size: 14px;
            color: #172554;
            margin: 20px 0 8px;
        }
        .table {
            width: 100%;
            border-collapse: collapse;
        }
        .table th, .table td {
            padding: 11px 12px;
            border: 1px solid #dbe2ea;
            text-align: left;
            font-size: 13px;
        }
        .table th { background: #e8edf5; }
        .amount { text-align: right !important; }
        .late-fee-row {
            background-color: #fef2f2 !important;
            color: #991b1b;
            font-weight: 700;
        }
        .arrear-link {
            font-weight: 700;
            color: #1d4ed8;
            text-decoration: none;
        }
        .summary {
            width: min(460px, 100%);
            margin: 18px 0 0 auto;
            border: 1px solid #cbd5e1;
            border-radius: 6px;
            overflow: hidden;
        }
        .sum-row {
            display: flex;
            justify-content: space-between;
            padding: 10px 13px;
            border-bottom: 1px solid #e2e8f0;
            font-size: 13.5px;
        }
        .sum-row.total {
            background: #172554;
            color: #fff;
            font-weight: 800;
            font-size: 15px;
        }
        .sum-row.total.overdue {
            background: #b91c1c;
        }
        .bank {
            margin-top: 20px;
            padding: 14px;
            background: #eff6ff;
            border-left: 4px solid #2563eb;
            font-size: 13px;
            line-height: 1.7;
            border-radius: 4px;
        }
        .terms {
            margin-top: 18px;
            color: #475569;
            font-size: 12px;
            line-height: 1.65;
        }
        .loading, .error {
            padding: 60px;
            text-align: center;
        }
        .error { color: #b91c1c; }
        @media(max-width: 700px) {
            .meta { grid-template-columns: 1fr; }
            .toolbar { align-items: flex-start; }
            .title { gap: 10px; }
            .body { padding: 14px; }
            .table { display: block; overflow: auto; }
            .brand { padding: 18px; }
            .btn { font-size: 12px; padding: 8px; }
        }
    </style>
</head>
<body>
<main class="page">
    <div class="toolbar">
        <a class="btn" href="fee-challan.html" onclick="if(history.length>1){event.preventDefault();history.back();}"><i class="fa-solid fa-arrow-left"></i> Back</a>
        <a class="btn primary" id="downloadBtn" href="#"><i class="fa-solid fa-download"></i> Download Challan</a>
    </div>
    <div class="sheet" id="content">
        <div class="loading">Loading challan...</div>
    </div>
</main>

<script>
const key = new URLSearchParams(location.search).get('key');
const local = ['localhost', '127.0.0.1'].includes(location.hostname);
const base = local ? 'http://localhost/lynxupdate' : 'https://erp.thelynxschool.edu.pk';
const api = base + '/api/public/v1';

const esc = v => {
    const d = document.createElement('div');
    d.textContent = String(v ?? '');
    return d.innerHTML;
};
const money = v => Number(v || 0).toLocaleString();

async function load() {
    if (!key) return fail('Invalid challan link.');
    try {
        const r = await fetch(api + '/challan-view', {
            headers: {
                Accept: 'application/json',
                Authorization: 'Bearer ' + key
            }
        });
        const j = await r.json();
        if (!r.ok) throw new Error(j.message || 'Unable to load challan.');
        render(j.data);
    } catch (e) {
        fail(e.message);
    }
}

function render(d) {
    const s = d.student || {};
    const c = d.challan || {};
    const f = d.financial_summary || {};
    const b = d.bank_details || {};
    const heads = d.heads || [];
    const arrears = d.arrears || [];

    const isOverdue = Boolean(f.is_overdue || (f.late_fee_amount > 0));
    const statusBadgeClass = isOverdue ? 'badge overdue' : 'badge';
    const statusText = isOverdue ? `${esc(c.status)} (Overdue)` : esc(c.status);

    const baseChallanAmount = Math.max(0, (f.net_current_challan || 0) - (f.late_fee_amount || 0));

    const lateFeeSummaryRow = (f.late_fee_amount > 0) ? `
        <div class="sum-row" style="background:#fef2f2;color:#991b1b;">
            <span><i class="fa-solid fa-clock-rotate-left"></i> Late Fee Surcharge (${f.days_overdue > 10 ? '10+ days max' : f.days_overdue + ' days'})</span>
            <strong>PKR ${money(f.late_fee_amount)}</strong>
        </div>
    ` : '';

    const summaryTotalBlock = (isOverdue && f.late_fee_amount > 0) ? `
        <div class="sum-row">
            <span>Payable by Due Date</span>
            <strong>PKR ${money(f.payable_by_due_date)}</strong>
        </div>
        <div class="sum-row total overdue">
            <span>Total Payable Now (incl. Late Fee)</span>
            <span>PKR ${money(f.payable_now || f.payable_after_due_date)}</span>
        </div>
    ` : `
        <div class="sum-row total">
            <span>Total Payable by Due Date</span>
            <span>PKR ${money(f.payable_by_due_date)}</span>
        </div>
    `;

    document.getElementById('downloadBtn').href = d.links.download_url;
    document.getElementById('content').innerHTML = `
        <div class="brand">
            <img src="assets/img/lnxlogo-removebg-preview(1).png" alt="The Lynx School">
            <h1>The Lynx School</h1>
            <p>${esc(s.branch_name)}</p>
        </div>
        <div class="title">
            <div>
                <h2>Fee Challan #${esc(c.challan_no)}</h2>
                <small>${esc(c.billing_month || c.fee_month_formatted)}</small>
            </div>
            <span class="${statusBadgeClass}">${statusText}</span>
        </div>
        <div class="body">
            <div class="meta">
                <div><label>Student</label><strong>${esc(s.name)}</strong></div>
                <div><label>Parent</label><strong>${esc(s.father_name || '-')}</strong></div>
                <div><label>Roll No</label><strong>${esc(s.roll_no)}</strong></div>
                <div><label>Class / Section</label><strong>${esc(s.class_name)} / ${esc(s.section_name)}</strong></div>
                <div><label>Issue Date</label><strong>${esc(c.issue_date_formatted)}</strong></div>
                <div><label>Due Date</label><strong>${esc(c.due_date_formatted)}</strong></div>
            </div>

            <h3 class="section-title">Fee Heads</h3>
            <table class="table">
                <thead>
                    <tr>
                        <th>Fee Head</th>
                        <th class="amount">Payable Amount</th>
                    </tr>
                </thead>
                <tbody>
                    ${heads.map(h => `
                        <tr class="${h.is_late_fee ? 'late-fee-row' : ''}">
                            <td>
                                ${esc(h.name)}
                                ${h.is_late_fee ? ' <span style="font-size:11px;padding:2px 5px;background:#fee2e2;color:#991b1b;border-radius:3px;">Late Surcharge</span>' : ''}
                            </td>
                            <td class="amount">PKR ${money(h.net_amount)}</td>
                        </tr>
                    `).join('')}
                </tbody>
            </table>

            ${arrears.length ? `
                <h3 class="section-title">Previous Arrears</h3>
                <table class="table">
                    <thead>
                        <tr>
                            <th>Challan</th>
                            <th>Fee Month</th>
                            <th class="amount">Unpaid Amount</th>
                        </tr>
                    </thead>
                    <tbody>
                        ${arrears.map(a => `
                            <tr>
                                <td><a class="arrear-link" href="challan-view.html?key=${encodeURIComponent(a.view_token)}">#${esc(a.challan_no)}</a></td>
                                <td>${esc(a.fee_month)}</td>
                                <td class="amount">PKR ${money(a.unpaid_balance)}</td>
                            </tr>
                        `).join('')}
                    </tbody>
                </table>
            ` : ''}

            <div class="summary">
                <div class="sum-row">
                    <span>Current Month Tuition / Heads</span>
                    <strong>PKR ${money(baseChallanAmount)}</strong>
                </div>
                ${lateFeeSummaryRow}
                <div class="sum-row">
                    <span>Previous Arrears</span>
                    <strong>PKR ${money(f.total_arrears)}</strong>
                </div>
                <div class="sum-row">
                    <span>Paid / Adjusted</span>
                    <strong>PKR ${money(f.received_paid_amount)}</strong>
                </div>
                ${summaryTotalBlock}
            </div>

            <div class="bank">
                <strong><i class="fa-solid fa-building-columns me-1"></i> ${esc(b.bank_name)} - ${esc(b.account_title)}</strong><br>
                Account #: ${esc(b.account_number)}<br>
                ${esc(b.branch_address)}
            </div>

            <div class="terms">
                ${(d.instructions?.payment_terms || []).map(t => `<div>${esc(t)}</div>`).join('')}
            </div>
        </div>
    `;
}

function fail(m) {
    document.getElementById('content').innerHTML = '<div class="error">' + esc(m) + '</div>';
    document.getElementById('downloadBtn').style.display = 'none';
}

load();
</script>
</body>
</html>